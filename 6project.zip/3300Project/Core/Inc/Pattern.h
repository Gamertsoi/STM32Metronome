/*
 * Pattern.h
 *
 *  Created on: Nov 24, 2024
 *      Author: Gamertsoi
 */

#ifndef INC_PATTERN_H_
#define INC_PATTERN_H_

extern const int pattern[28];

#endif /* INC_PATTERN_H_ */
