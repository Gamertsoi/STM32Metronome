/*
 * Pattern.c
 *
 *  Created on: Nov 24, 2024
 *      Author: Gamertsoi
 */
const int pattern[28] = {1,0,0,0, 0,0,1,0 ,1,0,1,0 ,1,1,1,0 ,1,1,1,1 ,1,0,1,1 ,1,1,0,1};
